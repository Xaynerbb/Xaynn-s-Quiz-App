const questions = [{
    question: 'Which mountain was Prophet Musa(A.S) given divine guidance by Allah',
    answers: [
    {text: 'Judi', correct: false},
    {text: 'Sinai', correct: true},
    {text: 'Tur', correct: false},
    {text: 'Nur', correct: false}
    ]
},
{
    question: 'Which Prophet ...(A.S) was thrown into the fire by his people',
    answers: [
    {text: 'Ibrahim', correct: true},
    {text: 'Musa ', correct: false},
    {text: 'Nuh', correct: false},
    {text: 'Adam', correct: false}
    ]
},
{
    question: "How many prophets where mentioned in the Glorious Qur'an",
    answers: [
    {text: 10, correct: false},
    {text: 35, correct: false},
    {text: 5, correct: false},
     {text: 25, correct: true}
    ]
},
{question: 'Who is the first wife of Prophet Muhammad(S.A.W)',
    answers: [
    {text: 'Khadijah', correct: true},
    {text: 'Zaynab', correct: false},
    {text: 'Aisha', correct: false},
    {text: 'Asmau', correct: false}
    ]
},
{
question: 'Who was the first Khalifah after the death of the Prophet(S.A.W)',
    answers: [
    {text: 'OMAR', correct: false},
    {text: 'ABUBAKR', correct: true},
    {text: 'USMAN', correct: false},
    {text: 'ALI', correct: false}
    ]
}, 
{
    question: 'What does Islam mean to muslims',
    answers: [
    {text: 'Peace', correct: false},
    {text: 'Light', correct: false},
    {text: 'Submission', correct: true},
    {text: 'Humility', correct: false}
    ]
},
{
    question: 'What does Assalamualaikum mean',
    answers: [
    {text: 'Light upon light', correct: false},
    {text: 'Peace be unto you', correct: true},
    {text: 'I leave you in the care of Allah', correct: false},
    {text: 'Allah has willed', correct: false}
    ]
}
];

const questionElement = document.getElementById('question');
const answerButtons = document.getElementById('answer-buttons');
const nextButton = document.getElementById('next-btn');

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = 'Next';
    showQuestion();
}
function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex +1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;
    
   // answerButton.innerHTML = "";
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement('button');
        button.innerHTML = answer.text;
        button.classList.add('btn');
        button.classList.add('fade-in');
        answerButtons.appendChild(button);
        if(answer.correct){
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}
function resetState(){
    nextButton.style.display = "none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
}
function selectAnswer(e){
   const selectedBtn = e.target;
   const isCorrect =  selectedBtn.dataset.correct ==='true'; 
   if(isCorrect){
       selectedBtn.classList.add("correct");
       score++;
   }   else{
       selectedBtn.classList.add("incorrect");
   }
    Array.from(answerButtons.children).forEach(button =>{
        if(button.dataset.correct === 'true'){
            button.classList.add('correct');
        }
        button.disabled = true;
    });
    nextButton.style.display = 'block';
}
function showScore(){
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
    nextButton.innerHTML = "Play Again";
    nextButton.style.display = 'block';
}
function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    } else{
        showScore();
    }
}
nextButton.addEventListener('click', ()=>{
    if(currentQuestionIndex < questions.length){
        handleNextButton();
    } else{
        startQuiz();
    }
})
startQuiz();